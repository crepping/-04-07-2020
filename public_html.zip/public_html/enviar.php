
<?php
if(isset($_POST['sendmail'])){
    if(mail($_POST['email'],$_POST['subject'],$_POST['message']))
    {
        echo "Mail Enviado";
    }else{
        echo "Error enviar email";
    }
}

?>

<form method="post" >
<label>Email</label>
<input type="text" name="email">
<label>sujeto</label>
<input type="text" name="subject">
<label>cuerpo</label>
<input type="text" name="message">
<button type="submit" name="sendmail">Enviar</button>
</form>