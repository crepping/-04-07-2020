$('.add_product').click(function(e){
e.preventDefault();
var codigo = $(this).attr('codigo');
alert(codigo);
});