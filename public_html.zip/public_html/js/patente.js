        

function checkRut(patente) {
    // Despejar Puntos
gion = "-"
patente =0;
if(patente.lenght > 2){
    
    patente=+guio;
}

}

