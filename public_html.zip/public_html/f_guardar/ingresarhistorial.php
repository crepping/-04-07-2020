<?php
include "../funciones/config.php";
ini_set('display_errors', 1);
$cnn = Conectar();
$codigo = $_POST['codigo'];
$session = $_POST['session'];
$aceite = $_POST['aceite'];
$detalle = $_POST['detalle'];
$hoy = date("Y-m-d H:i:s");
$in="insert into detalle(id,id_vehiculo,aceite,detalle,fecha_detalle) values('$session','$codigo','$aceite','$detalle','$hoy')";   
$dato=mysqli_query($cnn,$in); 
if (!$dato) {
  echo "<script> swal({
    title: '¡ERROR!',
    icon: 'error',
    text: 'Al ingresar el Detalle',
    type: 'error',
  });</script>";
}else{
echo"<br>"."<br>";
echo "<script> swal({
  position: 'top-center',
  icon: 'success',
  title: 'Detalle Ingresado',
  buttons: false,
  timer: 1500
});</script>";
//echo"<script type='text/javascript'>window.location='../pages/ingresoproductos.php'</script>";
//echo"<script type='text/javascript'>window.location='alumnotodos.php'</script>";
    }
  

?>