<?php
error_reporting(0);
$mysqli =new mysqli("localhost","aiepnet1_root","Jugando123","aiepnet1_proyecto");
if (isset($_POST['codigo'])){
         if ($_POST['action']=='infoProducto'){
            $variable=$_POST['codigo'];
$salida ="";
$query ="select *from detalle where id_vehiculo='$variable'";
$resultado = $mysqli->query($query);
if ($resultado->num_rows >0){
		$salida.="<form method='POST'>
		<div class='table-responsive'>
				<table class='table' id='page'>
				<thead>
				<tr>
				<!--<td></td>-->
					<td>Codigo</td>
					<td>Detalle</td>
					<td>Ingresado</td>
				</tr>
				</thead>
				<tbody>";
	while($fila=$resultado->fetch_assoc()){
$number++;
		$salida.="<tr>
		            <!--
					<td><a class=\"btn btn-info product1\" histo=".$fila['id_vehiculo']." data-toggle=\"modal\" data-target=\"#historial\"><i class=\"fas fa-laptop-medical\"></i></a></td>
					-->
					<td>".$fila['id_detalle']."</td>
					<td>".utf8_encode($fila['detalle'])."</td>
					<td>".utf8_encode($fila['fecha_detalle'])."</td>
				
				    <!--
					<td><a class=\"btn btn-primary\" href=\"veracuerdo.php?cod=".$fila['id']."\" target=\"_blank\" onclick=\"window.open(this.href,this.target,'width=900,height=900,top=200,left=200,toolbar=no,location=no,status=no,menubar=no');return false;\">Ver Acuerdo</a></div></td>
				    -->
				</tr>";	
	}
	$salida.="</tbody>
	</table>
	</div>
	</form>
	<script>
$(document).ready(function() {
$('#page').DataTable({
'language': {
'url': '//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json'
}
} );
} );
</script>";
}else{
	$salida.="<div class=\"alert alert-danger\" role=\"alert\">
  No hay Datos
</div>";

	}
	$mysqli->close();
	echo $salida; 
         }
}
?>

 
 