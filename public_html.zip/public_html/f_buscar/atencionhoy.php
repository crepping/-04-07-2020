<?php
date_default_timezone_set('America/Santiago');
ini_set('display_errors', 1);
error_reporting(0);
$mysqli =new mysqli("localhost","aiepnet1_root","Jugando123","aiepnet1_proyecto");
$hoy = date("d-m-Y");
$fechaActual = date('d-m-Y');
$salida ="";
$query ="select r.id_reserva,c.rut,c.nombres,c.apellidos,c.telefono,v.patente,r.id_vehiculo,r.fecha_reserv,r.Hora,r.ingreso_fecha from reserva r,cliente c, vehiculo v where r.id_reserva = r.id_reserva and r.id_cliente = c.id_cliente and r.id_vehiculo = v.id_vehiculo and r.estado_reserva = 2 order by r.id_reserva DESC";
if (isset($_POST['consulta'])) {
	$q = $mysqli->real_escape_string($_POST['consulta']);
	$query = "select r.id_reserva,c.rut,c.nombres,c.apellidos,c.telefono,r.id_vehiculo,v.patente,r.fecha_reserv,r.Hora,r.ingreso_fecha from reserva r,cliente c, vehiculo v where r.id_reserva = r.id_reserva and r.id_cliente = c.id_cliente and r.estado_reserva = 2 order by r.id_reserva DESC";
}
$resultado = $mysqli->query($query);
if ($resultado->num_rows >0){
	$salida.="
				<tr>
                <td></td>
                <td></td>
				    <td>Codigo</td>
					<td>Rut</td>
					<td>Nombre Cliente</td>
                    <td>Telefono</td>
					<td>Patente</td>
                    <td>Fecha_Reserva</td>
                    <td>Hora</td>
                    
				</tr>
				</thead>
				<tbody>";
	while($fila=$resultado->fetch_assoc()){
		$number++;
		$idvehiculo = $fila['id_vehiculo'];
		$salida.="<tr>
					
					<td><a class=\"btn btn-success product\" bar=".$fila['id_vehiculo']." data-toggle=\"modal\" data-target=\"#Ingreso\"><i class=\"fas fa-folder-plus\"></i></a></td>
                    <td><a class=\"btn btn-info product1\" codigo=".$fila['id_vehiculo']." data-toggle=\"modal\" data-target=\"#historial\"><i class=\"fas fa-laptop-medical\"></i></a></td>
					<!--<td>".$fila['id_reserva']."</td>-->
					<td>".$fila['id_vehiculo']."</td>
                    <td>".$fila['rut']."</td>
					<td>".$fila['nombres'].' '.$fila['apellidos']."</td>
                    <td>".$fila['telefono']."</td>
                    <td>".$fila['patente']."</td>
                    <td>".$fila['fecha_reserv']."</td>
                    <td>".$fila['Hora']."</td>
                   
					
				</tr>";	
	}
	$salida.="</tbody>";
}else{
	$salida.="
	<div class='col-sm-6'>
	<div class='alert alert-danger'><strong>Oh no!</strong> no hay Reservas para el dia de Hoy</div>
	<div class='col-sm-6'>
	";
 echo $fechaActual;
 echo $idvehiculo;
	}
	$mysqli->close();
	echo $salida;
	 
?>